function formValidation() {
    var fname = document.registration.name1;
    var lname = document.registration.name2;
    var passid = document.registration.passid;
    var uadd = document.registration.address;
    var uphn = document.registration.phn;
    var uemail = document.registration.email;
    var umsex = document.registration.msex;
    var ufsex = document.registration.fsex;


    if (allLetter(fname)) {
        if (all(lname)) {
            if (passid_validation(passid, 7, 12)) {
                if (alphanumeric(uadd)) {
                    if (allnumeric(uphn)) {
                        if (ValidateEmail(uemail)) {
                            if (validsex(umsex, ufsex)) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
    }
    return false;
}

function allLetter(fname) {
    var letters = /^(^[A-Z])[a-z]+$/;
    if (fname.value.match(letters)) {
        return true;
    }
    else {
        alert('First name must have alphabet characters only with UPPERcase 1st letter');
        fname.focus();
        return false;
    }
}

function all(lname) {
    var last = /^(^[A-Z])[a-z]+$/;
    if (lname.value.match(last)) {
        return true;
    }
    else {
        alert('Last name must have alphabet characters only with UPPERcase 1st letter');
        lname.focus();
        return false;
    }
}

function passid_validation(passid, mx, my) {
    var letters = /^[A-Z]/;
    var digit = /\d/;
    var specialCharacter = /[-_#&*]/;
    var whiteSpace = /\s/;
    var passid_len = passid.value.length;
    if (passid_len > 8 || passid_len < 8) {
        alert("Password length should be 8 characters only");
        passid.focus();
        return false;
    }
    else if (!(passid.value)[0].match(letters)) {
        alert("Password must start with a capital letter!");
        passid.focus();
        return false;
    }
    else if (!passid.value.match(digit)) {
        alert("Password must contain at least one digit!");
        passid.focus();
        return false;
    }
    else if (!passid.value.match(specialCharacter)) {
        alert("Password must contain at least one special character!");
        passid.focus();
        return false;
    }
    else if (passid.value.match(whiteSpace)) {
        alert("Password must not contain white spaces!");
        passid.focus();
        return false;
    }
    return true;
}

function alphanumeric(uadd) {
    var letters = /^[0-9a-zA-Z]+$/;
    if (uadd.value.match(letters)) {
        return true;
    }
    else {
        alert('User address must have alphanumeric characters only');
        uadd.focus();
        return false;
    }
}

function allnumeric(uphn) {
    var numbers = /^[0-9]+$/;
    if (uphn.value.length > 11 || uphn.value.length < 11) {
        alert('Phone no. must be 11 digits!');
        uphn.focus();
        return false;
    }
    else if (uphn.value.match(numbers)) {
        return true;
    }
    else {
        alert('Phone no. must have numeric characters only');
        uphn.focus();
        return false;
    }
}

function ValidateEmail(uemail) {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (uemail.value.match(mailformat)) {
        return true;
    }
    else {
        alert("You have entered an invalid email address!");
        uemail.focus();
        return false;
    }
}

function validsex(umsex, ufsex) {
    x = 0;

    if (umsex.checked) {
        x++;
    } if (ufsex.checked) {
        x++;
    }
    if (x == 0) {
        alert('Select Male/Female');
        umsex.focus();
        return false;
    }
    else {
        alert('Form Succesfully Submitted! Welcome to our website.');

        return true;
    }
}
